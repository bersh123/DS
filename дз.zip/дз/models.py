class Recipe:
    def __init__(self, id=None, title="", description="", cooking_time=0, servings=0, category=""):
        self.id = id
        self.title = title
        self.description = description
        self.cooking_time = cooking_time
        self.servings = servings
        self.category = category
    
    def to_dict(self):
        return {
            'id': self.id,
            'title': self.title,
            'description': self.description,
            'cooking_time': self.cooking_time,
            'servings': self.servings,
            'category': self.category
        }

class Ingredient:
    def __init__(self, id=None, recipe_id=None, name="", quantity="", unit=""):
        self.id = id
        self.recipe_id = recipe_id
        self.name = name
        self.quantity = quantity
        self.unit = unit
    
    def to_dict(self):
        return {
            'id': self.id,
            'recipe_id': self.recipe_id,
            'name': self.name,
            'quantity': self.quantity,
            'unit': self.unit
        }

class Step:
    def __init__(self, id=None, recipe_id=None, step_number=0, description=""):
        self.id = id
        self.recipe_id = recipe_id
        self.step_number = step_number
        self.description = description
    
    def to_dict(self):
        return {
            'id': self.id,
            'recipe_id': self.recipe_id,
            'step_number': self.step_number,
            'description': self.description
        }