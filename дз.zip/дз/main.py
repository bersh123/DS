from database import CookbookDB
from models import Recipe, Ingredient, Step

class CookbookApp:
    def __init__(self):
        self.db = CookbookDB()
    
    def display_menu(self):
        """Отображение главного меню"""
        print("\n=== КУЛИНАРНАЯ КНИГА ===")
        print("1. Показать все рецепты")
        print("2. Поиск рецептов")
        print("3. Рецепты по категориям")
        print("4. Добавить рецепт")
        print("5. Просмотреть рецепт")
        print("6. Удалить рецепт")
        print("7. Выйти")
    
    def show_all_recipes(self):
        """Показать все рецепты"""
        recipes = self.db.get_all_recipes()
        
        if not recipes:
            print("\nРецепты не найдены.")
            return
        
        print(f"\n=== ВСЕ РЕЦЕПТЫ ({len(recipes)}) ===")
        for recipe in recipes:
            print(f"{recipe.id}. {recipe.title} ({recipe.category}) - {recipe.cooking_time} мин, {recipe.servings} порций")
    
    def search_recipes(self):
        """Поиск рецептов"""
        search_term = input("\nВведите поисковый запрос: ").strip()
        
        if not search_term:
            print("Поисковый запрос не может быть пустым.")
            return
        
        recipes = self.db.search_recipes(search_term)
        
        if not recipes:
            print(f"\nРецепты по запросу '{search_term}' не найдены.")
            return
        
        print(f"\n=== РЕЗУЛЬТАТЫ ПОИСКА ({len(recipes)}) ===")
        for recipe in recipes:
            print(f"{recipe.id}. {recipe.title} ({recipe.category})")
    
    def show_recipes_by_category(self):
        """Показать рецепты по категориям"""
        categories = self.db.get_categories()
        
        if not categories:
            print("\nКатегории не найдены.")
            return
        
        print("\n=== КАТЕГОРИИ ===")
        for i, category in enumerate(categories, 1):
            print(f"{i}. {category}")
        
        try:
            choice = int(input("\nВыберите категорию (номер): ")) - 1
            if 0 <= choice < len(categories):
                category = categories[choice]
                recipes = self.db.get_recipes_by_category(category)
                
                print(f"\n=== РЕЦЕПТЫ: {category} ({len(recipes)}) ===")
                for recipe in recipes:
                    print(f"{recipe.id}. {recipe.title} - {recipe.cooking_time} мин, {recipe.servings} порций")
            else:
                print("Неверный выбор.")
        except ValueError:
            print("Пожалуйста, введите число.")
    
    def add_recipe(self):
        """Добавление нового рецепта"""
        print("\n=== ДОБАВЛЕНИЕ НОВОГО РЕЦЕПТА ===")
        
        title = input("Название рецепта: ").strip()
        description = input("Описание: ").strip()
        category = input("Категория: ").strip()
        
        try:
            cooking_time = int(input("Время приготовления (мин): "))
            servings = int(input("Количество порций: "))
        except ValueError:
            print("Время и порции должны быть числами.")
            return
        
        # Создание рецепта
        recipe = Recipe(
            title=title,
            description=description,
            cooking_time=cooking_time,
            servings=servings,
            category=category
        )
        
        recipe_id = self.db.add_recipe(recipe)
        print(f"\nРецепт '{title}' добавлен с ID: {recipe_id}")
        
        # Добавление ингредиентов
        print("\n--- Добавление ингредиентов ---")
        while True:
            add_more = input("Добавить ингредиент? (да/нет): ").lower()
            if add_more != 'да':
                break
            
            name = input("Название ингредиента: ").strip()
            quantity = input("Количество: ").strip()
            unit = input("Единица измерения: ").strip()
            
            ingredient = Ingredient(
                recipe_id=recipe_id,
                name=name,
                quantity=quantity,
                unit=unit
            )
            self.db.add_ingredient(ingredient)
            print(f"Ингредиент '{name}' добавлен.")
        
        # Добавление шагов приготовления
        print("\n--- Добавление шагов приготовления ---")
        step_number = 1
        while True:
            add_more = input(f"Добавить шаг {step_number}? (да/нет): ").lower()
            if add_more != 'да':
                break
            
            description = input(f"Шаг {step_number}: ").strip()
            
            step = Step(
                recipe_id=recipe_id,
                step_number=step_number,
                description=description
            )
            self.db.add_step(step)
            step_number += 1
        
        print(f"\nРецепт '{title}' полностью добавлен!")
    
    def view_recipe(self):
        """Просмотр полной информации о рецепте"""
        try:
            recipe_id = int(input("\nВведите ID рецепта: "))
        except ValueError:
            print("ID должен быть числом.")
            return
        
        recipe = self.db.get_recipe_by_id(recipe_id)
        if not recipe:
            print("Рецепт не найден.")
            return
        
        ingredients = self.db.get_ingredients_by_recipe(recipe_id)
        steps = self.db.get_steps_by_recipe(recipe_id)
        
        print(f"\n=== {recipe.title.upper()} ===")
        print(f"Категория: {recipe.category}")
        print(f"Описание: {recipe.description}")
        print(f"Время приготовления: {recipe.cooking_time} мин")
        print(f"Порций: {recipe.servings}")
        
        print("\nИНГРЕДИЕНТЫ:")
        if ingredients:
            for ingredient in ingredients:
                print(f"- {ingredient.name}: {ingredient.quantity} {ingredient.unit}")
        else:
            print("Ингредиенты не указаны.")
        
        print("\nШАГИ ПРИГОТОВЛЕНИЯ:")
        if steps:
            for step in steps:
                print(f"{step.step_number}. {step.description}")
        else:
            print("Шаги приготовления не указаны.")
    
    def delete_recipe(self):
        """Удаление рецепта"""
        try:
            recipe_id = int(input("\nВведите ID рецепта для удаления: "))
        except ValueError:
            print("ID должен быть числом.")
            return
        
        recipe = self.db.get_recipe_by_id(recipe_id)
        if not recipe:
            print("Рецепт не найден.")
            return
        
        confirm = input(f"Вы уверены, что хотите удалить рецепт '{recipe.title}'? (да/нет): ").lower()
        if confirm == 'да':
            self.db.delete_recipe(recipe_id)
            print(f"Рецепт '{recipe.title}' удален.")
        else:
            print("Удаление отменено.")
    
    def run(self):
        """Запуск приложения"""
        print("Добро пожаловать в Кулинарную книгу!")
        
        while True:
            self.display_menu()
            
            try:
                choice = int(input("\nВыберите действие: "))
            except ValueError:
                print("Пожалуйста, введите число.")
                continue
            
            if choice == 1:
                self.show_all_recipes()
            elif choice == 2:
                self.search_recipes()
            elif choice == 3:
                self.show_recipes_by_category()
            elif choice == 4:
                self.add_recipe()
            elif choice == 5:
                self.view_recipe()
            elif choice == 6:
                self.delete_recipe()
            elif choice == 7:
                print("До свидания!")
                break
            else:
                print("Неверный выбор. Попробуйте снова.")

if __name__ == "__main__":
    app = CookbookApp()
    app.run()