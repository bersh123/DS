import sqlite3
from models import Recipe, Ingredient, Step

class CookbookDB:
    def __init__(self, db_name="cookbook.db"):
        self.db_name = db_name
        self.init_database()
    
    def get_connection(self):
        return sqlite3.connect(self.db_name)
    
    def init_database(self):
        """Инициализация базы данных и создание таблиц"""
        conn = self.get_connection()
        cursor = conn.cursor()
        
        # Таблица рецептов
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS recipes (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                title TEXT NOT NULL,
                description TEXT,
                cooking_time INTEGER,
                servings INTEGER,
                category TEXT,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        ''')
        
        # Таблица ингредиентов
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS ingredients (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                recipe_id INTEGER,
                name TEXT NOT NULL,
                quantity REAL,
                unit TEXT,
                FOREIGN KEY (recipe_id) REFERENCES recipes (id) ON DELETE CASCADE
            )
        ''')
        
        # Таблица шагов приготовления
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS steps (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                recipe_id INTEGER,
                step_number INTEGER,
                description TEXT NOT NULL,
                FOREIGN KEY (recipe_id) REFERENCES recipes (id) ON DELETE CASCADE
            )
        ''')
        
        conn.commit()
        conn.close()
    
    # Методы для работы с рецептами
    def add_recipe(self, recipe):
        """Добавление нового рецепта"""
        conn = self.get_connection()
        cursor = conn.cursor()
        
        cursor.execute('''
            INSERT INTO recipes (title, description, cooking_time, servings, category)
            VALUES (?, ?, ?, ?, ?)
        ''', (recipe.title, recipe.description, recipe.cooking_time, recipe.servings, recipe.category))
        
        recipe_id = cursor.lastrowid
        conn.commit()
        conn.close()
        return recipe_id
    
    def get_all_recipes(self):
        """Получение всех рецептов"""
        conn = self.get_connection()
        cursor = conn.cursor()
        
        cursor.execute('SELECT * FROM recipes ORDER BY title')
        recipes = []
        for row in cursor.fetchall():
            recipes.append(Recipe(*row))
        
        conn.close()
        return recipes
    
    def get_recipe_by_id(self, recipe_id):
        """Получение рецепта по ID"""
        conn = self.get_connection()
        cursor = conn.cursor()
        
        cursor.execute('SELECT * FROM recipes WHERE id = ?', (recipe_id,))
        row = cursor.fetchone()
        recipe = Recipe(*row) if row else None
        
        conn.close()
        return recipe
    
    def search_recipes(self, search_term):
        """Поиск рецептов по названию или описанию"""
        conn = self.get_connection()
        cursor = conn.cursor()
        
        cursor.execute('''
            SELECT * FROM recipes 
            WHERE title LIKE ? OR description LIKE ?
            ORDER BY title
        ''', (f'%{search_term}%', f'%{search_term}%'))
        
        recipes = []
        for row in cursor.fetchall():
            recipes.append(Recipe(*row))
        
        conn.close()
        return recipes
    
    def get_recipes_by_category(self, category):
        """Получение рецептов по категории"""
        conn = self.get_connection()
        cursor = conn.cursor()
        
        cursor.execute('SELECT * FROM recipes WHERE category = ? ORDER BY title', (category,))
        
        recipes = []
        for row in cursor.fetchall():
            recipes.append(Recipe(*row))
        
        conn.close()
        return recipes
    
    def update_recipe(self, recipe):
        """Обновление рецепта"""
        conn = self.get_connection()
        cursor = conn.cursor()
        
        cursor.execute('''
            UPDATE recipes 
            SET title = ?, description = ?, cooking_time = ?, servings = ?, category = ?
            WHERE id = ?
        ''', (recipe.title, recipe.description, recipe.cooking_time, recipe.servings, recipe.category, recipe.id))
        
        conn.commit()
        conn.close()
    
    def delete_recipe(self, recipe_id):
        """Удаление рецепта"""
        conn = self.get_connection()
        cursor = conn.cursor()
        
        cursor.execute('DELETE FROM recipes WHERE id = ?', (recipe_id,))
        
        conn.commit()
        conn.close()
    
    # Методы для работы с ингредиентами
    def add_ingredient(self, ingredient):
        """Добавление ингредиента"""
        conn = self.get_connection()
        cursor = conn.cursor()
        
        cursor.execute('''
            INSERT INTO ingredients (recipe_id, name, quantity, unit)
            VALUES (?, ?, ?, ?)
        ''', (ingredient.recipe_id, ingredient.name, ingredient.quantity, ingredient.unit))
        
        conn.commit()
        conn.close()
    
    def get_ingredients_by_recipe(self, recipe_id):
        """Получение ингредиентов рецепта"""
        conn = self.get_connection()
        cursor = conn.cursor()
        
        cursor.execute('SELECT * FROM ingredients WHERE recipe_id = ? ORDER BY id', (recipe_id,))
        
        ingredients = []
        for row in cursor.fetchall():
            ingredients.append(Ingredient(*row))
        
        conn.close()
        return ingredients
    
    # Методы для работы с шагами приготовления
    def add_step(self, step):
        """Добавление шага приготовления"""
        conn = self.get_connection()
        cursor = conn.cursor()
        
        cursor.execute('''
            INSERT INTO steps (recipe_id, step_number, description)
            VALUES (?, ?, ?)
        ''', (step.recipe_id, step.step_number, step.description))
        
        conn.commit()
        conn.close()
    
    def get_steps_by_recipe(self, recipe_id):
        """Получение шагов приготовления рецепта"""
        conn = self.get_connection()
        cursor = conn.cursor()
        
        cursor.execute('SELECT * FROM steps WHERE recipe_id = ? ORDER BY step_number', (recipe_id,))
        
        steps = []
        for row in cursor.fetchall():
            steps.append(Step(*row))
        
        conn.close()
        return steps
    
    def get_categories(self):
        """Получение всех категорий"""
        conn = self.get_connection()
        cursor = conn.cursor()
        
        cursor.execute('SELECT DISTINCT category FROM recipes WHERE category IS NOT NULL ORDER BY category')
        
        categories = [row[0] for row in cursor.fetchall()]
        
        conn.close()
        return categories